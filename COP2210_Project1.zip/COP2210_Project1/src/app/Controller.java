/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */// PROGRAMMER: Nathan Scott Jr
// PANTHER ID: 6274578
//
// CLASS: COP2210
// SECTION: Your class section: RVD1208
// SEMESTER: The current semester: Fall2020
// CLASSTIME: Your COP2210 course meeting time :T/TH 9:00-10:15 am
//
// Project: Put what this project is: Project 1
// DUE:September 13,2020
//
// CERTIFICATION: I understand FIU’s academic policies, and I certify that this work is my
// own and that none of it is the work of any other person.
//=============================================================================
package app;

import motor.Duramax;
import motor.V6;
import vehicle.Truck;
import tool.Analyzer;

/**
 *
 * @author Nathan
 */
public class Controller {
    Duramax motor1 = new Duramax();
    Duramax motor2 = new Duramax(8);
    
   motor1.scan("");
    
   motor2.scan("\t");
    
    
    V6 motor3 = new V6();
    motor3.scan("\t\t");
    
    
    Truck truck1 = new Truck("Colorado" motor1);
    
    
    truck1.scan();
   
  
    
   Truck truck2 = new Truck("Colorado", motor3, 2014);
    truck2.scan();
    
    
    
    Analyzer.getScanner().scanVehicle(truck1);
    Analyer.getScanner().scanVehicle(truck2);
     
    
    
    
    
  
    
    
    
    
    
    
    
   
    
   
    
      
    
}
