/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tool;

import java.text.SimpleDateFormat;
import java.util.Date;
import vehicle.Truck;

/**
 *
 * @author Nathan
 */
public class Scanner {
    public int numberOfScans = 0;
    private String anaylzerID;
    public String ScannerID = "SCAN-X123-789-A";
    
    

  //Constructor
public Scanner(String anaylzer){
 this.anaylzerID = anaylzerID;
 
}

public void scanVehicle(Truck truck){
    String pattern = "E, MMM dd, yyyy HH:mm:ss.SSS";
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
    String date = simpleDateFormat.format(new Date());
    System.out.println("");
    System.out.println("============================================");
    System.out.println("Scanning Vehicle: ");
    System.out.println("============================================");
    System.out.printf("Current Time: \t %-20s \n", date);
    System.out.printf("Analyzer ID: \t %-10s \n", anaylzerID);
    System.out.printf("ScannerID: \t %-10s \n", ScannerID);
    
    System.out.println("=======Vehicle Info===========");
    
    System.out.printf("Model: \t\t %-10s \n", truck.getModel());
    System.out.printf("Year Build: \t %-10d \n", truck.getYearBuild());
    System.out.printf("Year Build: \t %-10.2f \n ", truck.getNewPrice());
    System.out.printf("VIn: \t\t %-10s \n", truck.getVIN());
    System.out.printf("Mileage: \t %-10d \n", truck.getMileage());
    System.out.printf("Last Service: \t %-10s \n", truck.getLastServiceDate());
    
    
    System.out.println("");
    System.out.println("=============Motor Scan========");
    
    
    if(truck.getDuramaxMotor() != null){
        System.out.printf("Cylinders: \t %-10d \n", truck.getDuramaxMotor().getNumberOfCylinder());
        System.out.printf("Displacement: \t %-10.2f \n",truck.getDuramaxMotor().getDisplacement());
        System.out.printf("FuelType: \t %-10s \n", truck.getDuramaxMotor().getFuelType());
        System.out.printf("Serial Number: \t %-10s \n", truck.getDuramaxMotor().getSerialNumber());
        
        
        System.out.printf("Torque \t\t %-10.3f \n", truck.getDuramaxMotor().engineScannerTorque());
        System.out.printf("HP: \t\t %-10.3f \n", truck.getDuramaxMotor().engineScannerHP());
        
    
}
    if(truck.getV6Motor() !=null){
        System.out.printf("Cylinders: \t  %-10d \n", truck.getV6Motor().getNumberOfCylinders());
        System.out.printf("Displacement: \t %-10.2f \n", truck.getV6Motor().getDisplacement());
        System.out.printf("FuelType: \t %-10s \n", truck.getV6Motor().getFuelType());
        System.out.printf("Serial Number \t %-10s \n", truck.getV6Motor().getSerialNumber());
        
        
        System.out.printf("Torque: \t\t %-10.3f \n", truck.getV6Motor().engineScannerTorque());
        System.out.printf("HP: \t\t %-10.3f \n", truck.getV6Motor().engineScannerHP());
    }
    
    System.out.println("");
    System.out.println("Upadating Last Service Date ->" +date);
    truck.setLastServiceDate(date);
    numberOfScans++;
    
    
    
    
    
    
}
}
