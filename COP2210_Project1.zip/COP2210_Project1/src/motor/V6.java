/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motor;

/**
 *
 * @author Nathan
 */
public class V6 {
    public String SERIAL_ID = "GM-V6-LFZ";
    public String FACTORY_LOCATION = "Michigan";
    public int engineCounter = 12000;
    private double displacement;
    private int numberOfCylinders;
    private String serialNumber;
    private String fuelType;
    private double mpg;
    
    //Constructor
    private double TORQUE_CONSTANT;
    private double Torque;
    
    

       public V6(){
          displacement = 3.600;
      serialNumber = SERIAL_ID + FACTORY_LOCATION + engineCounter;
      engineCounter++;
      
      numberOfCylinders = 6;
      fuelType = "Gas";
      
      
      
     
}

   
       public String getSERIAL_ID(){
           return SERIAL_ID;
       }
       
       public String getFACTORY_LOCATION(){
           return FACTORY_LOCATION;
       }
       
       public int getEngineCounter(){
           return engineCounter;
       }
       
       public double getDisplacement(){
           return displacement;
       }
       
       public int getNumberOfCylinders(){
           return numberOfCylinders;
       }
       
       public String getSerialNumber(){
           return serialNumber;
       }
       public String getFuelType(){
           return fuelType;
       }
       public double getMpg(){
           return mpg;
       }
       
       public double engineScannerTorque(){
        return calculateTorque();
       }
       
       public double engineScannerHP(){
        return calculateHP();
           
       }
       
       private double calculateTorque(){
        final double CYLINDER_LOAD_FACTOR = 1220.13;
        final double TORQUE_CONSTANT = 142.4;
        double torque = 0.0;
        
        
        torque = CYLINDER_LOAD_FACTOR *Math.pow(Math.pow(displacement/numberOfCylinders,2)*Math.exp(TORQUE_CONSTANT),0.59);
        
        return torque;
        
        
           
       }
       
       private double calculateHP(){
           double hp = 0.0;
           hp = (2*Math.PI*4700*Torque/33000)*(1.11);
           return hp;
       }
       
       public void scan(String spacer){
           System.out.println(spacer + "");
           System.out.println(spacer + "=================================");
           System.out.println(spacer + "Scanning V6");
           System.out.println(spacer + "==========================================");
           System.out.printf(spacer + "Displacement: \t\t %-10.3f \n", displacement);
           System.out.printf(spacer + "NumberOfCylinders: \t %-10d \n", numberOfCylinders);
           System.out.printf(spacer + "FuelType: \t\t %-10s \n", fuelType);
           System.out.printf(spacer + "SerialNumber: \t\t %-10s \n", serialNumber);
           System.out.printf(spacer + "Mpg: \t\t\t %-10.3f \n", mpg);
           
           
           System.out.printf(spacer + "Torque: \t\t\t %-10.3f", calculateTorque());
           System.out.printf(spacer + "HP: \t\t\t %-10.3f", calculateHP());
           
         
           
       }

  
       

}
