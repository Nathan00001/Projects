/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motor;

/**
 *
 * @author Nathan
 */
public class Duramax {
    public String SERIAL_ID = "GM-DMAX-";
    public String FACTORY_LOCATION = "OHIO-";
    public int engineCounter = 5500;
    private double displacement;
    private int numberOfCylinders;
    private String serialNumber;
    private String fuelType;
    private double mpg;
    private int numberOfCylinder;
    private double torque;
    private double HP;
    private double t1;
    private double t3;
    private double CYLINDER_LOAD_FACTOR;
    private double TORQUE_CONSTANT;
   
    

//Counstructor 

public Duramax(){
 
    
        
serialNumber = SERIAL_ID + FACTORY_LOCATION + engineCounter;
   
  engineCounter = engineCounter++;
        
   displacement = 2.8;
   numberOfCylinders = 4;
   fuelType = "Diesel";
   mpg = 25;
   
   
        
    


}

public Duramax(int numberOfCylinder){
    this.numberOfCylinders = numberOfCylinders;
    
    
    if(numberOfCylinder == 8);{}
    displacement = 6.6;
    mpg = 19.6;
    
    
}
public String getSERIAL_ID(){
    return SERIAL_ID;
}
public String getFACTORY_LOCATION(){
return FACTORY_LOCATION;
}
public int getEngineCounter(){
    return engineCounter;
}

public double getDisplacement(){
    return displacement;
}
public int getNumberOfCylinder(){
    return numberOfCylinders;
}
public String getSerialNumber(){
    return serialNumber;
}
public String getFuelType(){
    return fuelType;
}
public double getMPG(){
    return mpg;
}

public double engineScannerTorque(){
   double Torque;
        return 0;
     
        
}

public double engineScannerHP(){
    double HP;
        return 0;
}

private double calculateTorque(){
    torque = (CYLINDER_LOAD_FACTOR) * t3;
    double t2 = Math.exp(TORQUE_CONSTANT);
    double t3 = Math.pow(t1 * t2, 0.59);
    return torque;
    
     
}

private double calculateHP(){
    HP = Math.sqrt((Math.PI *4700 * torque) / 33000) * Math.pow(numberOfCylinders, 1.926);
    return HP;
}
public void Scan(String spacer){
    System.out.println(spacer + "");
    System.out.println(spacer + "========================");
    System.out.println(spacer + "Scanning Duramax");
    System.out.println(spacer + "========================");
    System.out.printf(spacer + "Displacement: \t\t %-10.3f \n", displacement);
    System.out.printf(spacer + "Number of Cylinder: \t %-10d \n", numberOfCylinders);
    System.out.printf(spacer + "FuelType: \t\t %-10s \n", fuelType);
    System.out.printf(spacer + "SerialNumber: \t\t %10s \n", serialNumber);
    System.out.printf(spacer + "MPG: \t\t\t %-10.3f \n", mpg);
    
    
    
    
    System.out.printf(spacer + "Torque: \t\t\t %-10.3f \n", calculateTorque());
    System.out.printf(spacer + "HP: \t\t\t %-10.3f \n",calculateHP());
    
    
}

  


}



        
