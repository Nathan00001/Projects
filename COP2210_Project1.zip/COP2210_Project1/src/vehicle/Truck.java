/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

import java.util.Random;
import motor.Duramax;
import motor.V6;

/**
 *
 * @author Nathan
 */
public class Truck {
    private int numberOfCarCreated = 0;
    private int nextNumberID = 1000;
    private String VIN_CONSTANT = "VIN-";
    private String model;
    private int mileage;
    private double newPrice;
    private int yearBuild;
    private Duramax duramaxMotor;
    private V6 v6Motor;
    private String vin;
    private String lastServiceDate;
    
    public Truck(String V6, String serialNumber){
        
        
        this.yearBuild = yearBuild;
        this.model = model;
        
        Random rndGen = new Random(); 
        
        vin = VIN_CONSTANT + model + "-" + yearBuild + "-" + V6 + serialNumber;
        
      
            newPrice = rndGen.nextInt(15001);
            mileage = rndGen.nextInt(12001) + 25000;
        
            
        
        
    }
    
   public Truck(String model, Duramax duramax){
       this.model = "Colorado";
       duramaxMotor = null;
       
       
       
       
       
   }
   
   public Truck(String model, Duramax duramax, int yearBuild){
       duramaxMotor = duramax;
       this.model = model;
       yearBuild = 2020;
       
       
       
   }
   
  public Truck(String model, V6 v6, int yearBuild){
      v6Motor = new V6();
      yearBuild =2014;
      model = null;
      
     
  }

  
  
  public int getNumberOfCarCreated(){
      return numberOfCarCreated;
  }
  
  
  public int getNextNumberID(){
      return nextNumberID;
  }
  
  public String getVIN_CONSTANT(){
      return VIN_CONSTANT;
  }
  
  public String getModel(){
      return model;
  }
  
  public int getMileage(){
      return mileage;
  }
  
  public double getNewPrice(){
      return newPrice;
  }
  
  public int getYearBuild(){
      return yearBuild;
  }
  
  public Duramax getDuramaxMotor(){
      return duramaxMotor;
  }
  
  public V6 getV6Motor(){
      return v6Motor;
  }
  
  public String getVIN(){
      return vin;
  }
  
  public String getLastServiceDate(){
      return lastServiceDate;
  }
  
  public void setLastServiceDate(String LastServiceDate){
       this.lastServiceDate = lastServiceDate;
       
       
  
       }
  public void scan(){
      System.out.println("");
      System.out.println("===============================================");
      System.out.println("Scanning Truck");
      System.out.println("===============================================");
      System.out.printf("Model: \t\t %-10s \n", model);
      System.out.printf("YearBuild: \t\t %-10d \n", yearBuild);
      System.out.printf("VIN: \t\t %-10s \n", vin);
      System.out.printf("Mileage: \t\t %-10d", mileage);
      
      
      System.out.println("");
      
      if(duramaxMotor !=null){
          duramaxMotor.scan("\t");
      }
      if(v6Motor !=null){
          v6Motor.scan("\t");
      }
  }

  
}
  






