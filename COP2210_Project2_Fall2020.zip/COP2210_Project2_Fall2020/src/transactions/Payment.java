/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package transactions;

/**
 *
 * @author Nathan
 */
public class Payment {
    private double DOLLARVALUE = 1.00;
    private double QUATERVALUE = 0.25;
    private double DIMEVALUE = 0.10;
    private double NICKELVALUE = 0.05;
    private double PENNYVALUE = 0.01;
    private int numberOfOneDollarBills;
    private int numberOfQuarters;
    private int numberOfDimes;
    private int numberOfNickels;
    private int numberOfPennies;
    
    public Payment(int numberOfOneDollarBills, int numberOfQuaters, int numberOfDimes, int numberOfNickels, int numberOfPennies){
        this.numberOfOneDollarBills = numberOfOneDollarBills;
        this.numberOfQuarters = numberOfQuaters;
        this.numberOfDimes = numberOfDimes;
        this.numberOfNickels = numberOfNickels;
        this.numberOfPennies = numberOfPennies;
    }
    public int getNumberOfOneDollarBills(){
        return numberOfOneDollarBills;
    }
    public int getNumberOfQuaters(){
        return numberOfQuarters;
    }
    public int getNumberOfDimes(){
        return numberOfDimes;
    }
    public int getNumberOfNickels(){
        return numberOfNickels;
    }
    public int getNumberOfPennies(){
        return numberOfPennies;
    }
    public void displayInfo(){
        System.out.println("====================================");
        System.out.println("Payment Info");
        System.out.println("====================================");
        System.out.printf("Number Of Dollar: \t %-15d\n", numberOfOneDollarBills);
        System.out.printf("Number Of Quarters: \t %-15d \n", numberOfQuarters);
        System.out.printf("Number Of Dimes: \t %-15d\n", numberOfDimes);
        System.out.printf("Number Of Nickels: \t %-15d\n", numberOfNickels);
        System.out.printf("Number Of Pennies: \t %-15d\n", numberOfPennies);
        System.out.println("");
    }
    public double paymentValue(){
        double total = numberOfOneDollarBills * DOLLARVALUE + 
                numberOfQuarters * QUATERVALUE + 
                numberOfDimes * DIMEVALUE + 
                numberOfNickels * NICKELVALUE +
                numberOfPennies * PENNYVALUE;
        return total;
    }
}
