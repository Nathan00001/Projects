//=============================================================================
// PROGRAMMER: Nathan Scott Jr
// PANTHER ID: 6274578
//
// CLASS: COP2210
// SECTION: Your class section: RVD 1208
// SEMESTER: The current semester:  Fall 2020
// CLASSTIME: Your COP2210 course meeting time :example T/TH 9:00-10:15 am
//
// Project: Put what this project is: Project 2
// DUE:Nov 8th
//
// CERTIFICATION: I understand FIU’s academic policies, and I certify that this work is my
// own and that none of it is the work of any other person.
//=============================================================================
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import food.Apple;
import food.Sandwich;
import machine.Register;
import transactions.Payment;

/**
 *
 * @author Nathan
 */
public class Controller {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("=========================");
        System.out.println("COP 2210 - Project 2 Output");
        System.out.println("Nathan Scott jr");
        System.out.println("6274578");
        System.out.println("RVD 1208");
        System.out.println("=========================");
        System.out.println("\n");
 
 // create a Register varaible named register with
 // 15 dollars
 // 20 quarters
 // 10 dimes
 // 20 nickels
 // 50 pennies
  Register Register = new Register(15,20,10,20,50);

 
// check register cash as a "Manager"
 // call the cashInfo method on the register object with input "Manager"
  Register.cashInfo("Manager");
  
  // check register cash as a "Staff"
 // call the cashInfo method on the register object with input "Staff"
  Register.cashInfo("Staff");
 
        // create an Apple variable named grannySmith with
        // type = "Granny Smith"
        // weight = 1.51
        // pricePreUnitWeight = 140
    Apple grannySmith = new Apple("Granny Smith", 140, 1.51);

 // call displayInfo() on the grannySmith object
   grannySmith.displayInfo();

 // create an Payment variable named applePayment1 with
 // 10 dollars
 // 0 quarters
 // 0 dimes
 // 0 nickels
 // 47 pennies
 // YOUR CODE HERE
  Payment applePayment1 = new Payment(10, 0, 0, 0, 47);

 // call displayInfo() on the applePayment1 object
  applePayment1.displayInfo();

 // call the buyApple method on the register object with
 // inputs grannySmith, applePayment1
    

 // check register cash as a "Manager"
 // call the cashInfo method on the register object with input "Manager"
        // create an Apple variable named macintosh with
        // type = "Macintosh"
        // weight = 1.70
        // pricePreUnitWeight = 150
       Apple macintosh= new Apple("macintosh", 1.70, 150);
   
 
 
 // call displayInfo() on the macintosh object
   macintosh.displayInfo();
 
// create a Payment variable named applePayment2 with
 // 0 dollars
 // 2 quarters
 // 0 dimes
 // 0 nickels
 // 0 pennies
  Payment applePayment2 = new Payment(0,2,0,0,0);
  
  
  
  

 // call displayInfo() on the applePayment2 object
  applePayment2.displayInfo();

 // call the buyApple method on the register object with
 // inputs macintosh, applePayment2
 Register.buyApple(macintosh, applePayment2);

 // check register cash as a "Manager"
 // call the cashInfo method on the register object with input "Manager"
 // YOUR CODE HERE
 // create an Sandwich variable named sandwich with
 // meat = true
 // cheese = true
 // veggies = true
 Sandwich sandwich = new Sandwich(true, true, true);

 // call displayInfo() on the sandwich object
  sandwich.displayInfo();

 // create an Payment variable named sandwichPayment1 with
 // 5 dollars
 // 2 quarters
 // 1 dimes
 // 1 nickels
 // 2 pennies
 Payment sandwichPayment1 = new Payment (5, 2, 1, 1, 2);

 // call displayInfo() on the sandwichPayment1 object
 sandwichPayment1.displayInfo();
 // call the buySandwich method on the register object with
 // inputs sandwich, sandwichPayment1
 Register.buySandwich(sandwich, sandwichPayment1);

 // check register cash as a "Manager"
 // call the cashInfo method on the register object with input "Manager"
 Register.cashInfo("Manager");

 // create booleans
 boolean meat = true;
 boolean cheese = true;
 boolean veggies = true;

 System.out.println("");

 // Create all type sandwichs combinations
 // then buy each sandwich by creating a payment with
 // 10 dollars
 // 0 quarters
 // 0 dimes
 // 0 nickels
 // 0 pennies
 
 Payment sandwichPayment2 = new Payment(10,0,0,0,0);
 Sandwich sandwich2 = new Sandwich(meat, cheese, veggies);
 // YOU MUST USE A FOR LOOP AND IF ELSE STATMENTS
 
 int j=0, k= 0;
for(int i = 0; i < 8; i++ ){
      if(i < 4){
        
      if(j == 0 || j==1){
         
       if(k %2 == 0){
       sandwich2 = new Sandwich(meat, cheese, veggies);
    }else{
        sandwich2 = new Sandwich(meat, cheese, veggies);
      }
    }if(j%2 == 0){
        sandwich2 = new Sandwich(meat, cheese, veggies);
    }else{
        sandwich2 = new Sandwich(meat, cheese, veggies);
    }if(j ==4 || j == 5){
        if(k%2 == 0){
        sandwich2 = new Sandwich(meat, cheese , veggies);
        }
  }else{
        sandwich2 = new Sandwich(meat, cheese, veggies);
}
  if(k %2 == 0){
      sandwich2 = new Sandwich(meat, cheese, veggies);
  }else{
      sandwich2 = new Sandwich(meat, cheese, veggies);
  }
 System.out.println("");
    
}//end main
 }//end class
sandwich2.displayInfo();
 Register.buySandwich(sandwich2,sandwichPayment2);
 Register.cashInfo("Manger");
 j++;
 k++;
         
 }
}

