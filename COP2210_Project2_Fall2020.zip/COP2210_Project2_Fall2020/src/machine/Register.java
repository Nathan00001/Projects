/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package machine;

import food.Apple;
import transactions.Payment;
import food.Sandwich;

/**
 *
 * @author Nathan
 */
public class Register {
    private int registerCounter = 0;
    private String REGISTERCODE = "US-FL-032020-";
    private double DOLLARVALUE = 1.00;
    private double QUATERVALUE = 0.25;
    private double DIMEVALUE = 0.10;
    private double NICKELVALUE = 0.05;
    private double PENNYVALUE = 0.01;
    private String registerID;
    private int numberOfOneDollarBills;
    private int numberOfQuarters;
    private int numberOfDimes;
    private int numberOfNickels;
    private int numberOfPennies;
    private double currentTotal;
   
    
  //----------------------------------------------------------
 // Constructor
 //----------------------------------------------------------
 public Register(int numberOfOneDollarBills, int numberOfQuarters, int numberOfDimes, int numberOfNickels, int numberOfPennies){

 // increment registerCounter by one
   registerCounter++;


 // set registerID to REGISTERCODE + registerCounter
  registerID = REGISTERCODE + registerCounter;


 currentTotal = 0.0;

// set the constructor inputs values to the register instant variables
// hint code:
 // this.numberOfOneDollarBills = numberOfOneDollarBills;
  this.numberOfOneDollarBills = numberOfOneDollarBills;
  this.numberOfQuarters = numberOfQuarters;
  this.numberOfDimes = numberOfDimes;
  this.numberOfNickels = numberOfNickels;
  this.numberOfPennies = numberOfPennies;
 }

 //----------------------------------------------------------
 // Utility methods
 // Check UML Diagram
 //----------------------------------------------------------

 private double cashValue(){

 double total = numberOfOneDollarBills * DOLLARVALUE +
 numberOfQuarters * QUATERVALUE +
numberOfDimes * DIMEVALUE +
numberOfNickels * NICKELVALUE +
numberOfPennies * PENNYVALUE;

 return total;

 }

 public void cashInfo(String personal){
 
 // if the personal is a Manager
 // then output the cashValue of the register
 // hint code:
if(personal.equals("Manager")){
 System.out.println("==========================================");
 System.out.println("Register Cash Info");
 System.out.println("==========================================");
 System.out.println("Access Level:\t\t Valid");
 System.out.printf("Cash in the Register:\t $%-15.2f\n", cashValue());
 System.out.printf("Dollars:\t\t %-15d\n", numberOfOneDollarBills);
 System.out.printf("Quarters:\t\t %-15d\n", numberOfQuarters);
 System.out.printf("Dimes:\t\t\t %-15d\n", numberOfDimes);
 System.out.printf("Nickels: \t\t %-15d\n", numberOfNickels);
 System.out.printf("Pennies: \t\t %-15d\n", numberOfPennies);
}

 // else the personal is not a Manager the denied access
 // hint code:
 else{
 System.out.println("==========================================");
 System.out.println("Register Cash Info");
 System.out.println("==========================================");
 System.out.println("Access Level:\t\t Not Valid by " + personal);
 System.out.println("");
}
// hint use an if else statement
 }
 int shortAmount = 0;
 public void buyApple(Apple apple, Payment payment){
 System.out.println("==========================================");
 System.out.println("Register Buy Apple");
 System.out.println("==========================================");
 System.out.printf("Apple Price:\t\t $%-15.2f\n" , apple.price() );
 System.out.printf("Payment:\t\t $%-15.2f\n" , payment.paymentValue() );

// check if you have enough payment to buy the apple
// if your payment is less the apple price calculate the amount short
// and output to the console
// Sorry but you do not have enough money to buy the Apple
// hint code:
 if(payment.paymentValue()< apple.price()){  
double shortAmount = apple.price()-payment.paymentValue();
 System.out.printf("You need:\t\t $%-15.2f\n",shortAmount);
 System.out.println("");
 System.out.println("Sorry but you do not have enough money to buy the Apple");
 System.out.println("==========================================");
 System.out.println("\n");
 }else{
     giveChange(apple.price(), payment);
 }
// else you have enough payment then give change to buyer
// hence call the giveChange method with the apple price and payment
// hint: use an if else statement
// YOUR CODE HERE

 }//end buyApple()


 public void buySandwich(Sandwich sandwich, Payment payment){
 System.out.println("==========================================");
 System.out.println("Register Buy Sandwich");
 System.out.println("==========================================");

 // check if you have enough payment to buy the sandwich
// if your payment is less the sandwich price calculate the amount short
// and output to the console
// Sorry but you do not have enough money to buy the Sandwich
if(payment.paymentValue()< sandwich.getPrice()){
 
System.out.printf("Sandwich Price:\t\t $%-15.2f\n" , sandwich.getPrice() );
System.out.printf("Payment:\t\t $%-15.2f\n" , payment.paymentValue() );

 System.out.println("");
 System.out.println("Sorry but you do not have enough money to buy the Sandwich");
 System.out.println("==========================================");
 System.out.println("\n");
}else{
    giveChange(sandwich.getPrice(), payment);
}
// else you have enough payment then give change to buyer
// hence call the giveChange method with the sandwich price and payment
// hint: use an if else statement
// YOUR CODE HERE

 }//end buySandwich()
 private void giveChange(double price, Payment payment){

 // add payment to register
// hint code:
 // numberOfOneDollarBills += payment.getNumberOfOneDollarBills();
 // YOUR CODE HERE
 numberOfOneDollarBills += payment.getNumberOfOneDollarBills();
 numberOfQuarters += payment.getNumberOfQuaters();
 numberOfDimes += payment.getNumberOfDimes();
 numberOfNickels += payment.getNumberOfNickels();
 numberOfPennies += payment.getNumberOfPennies();
 // calculate needed change
 double neededChange = payment.paymentValue() - price;
 // rounded to whole number so you can use the % operator for the change
// example 9.65 becomes 965
 int neededChangeWhole = (int)Math.round(neededChange * 100);

 System.out.printf("Change:\t\t $%-15.2f\n", neededChange);

 // figure out the dollar to give back
 // hint: 965 /100 = 9 because of the int/ int
 // so you have 9 dollars
 // update the remaining change to give back
 // 965 – 900 = 65 this is the cents you need to give back
 // figure out the quarters to give back
  int changeDollars = neededChangeWhole / 100;
  neededChangeWhole = neededChangeWhole %100;

 // update the remaining change to give back
 int changeQuarters = neededChangeWhole / 25;
 neededChangeWhole = neededChangeWhole %25;
 // figure out the dimes to give back
 int changeDimes = neededChangeWhole / 10;
 neededChangeWhole = neededChangeWhole %10;

 // update the remaining change to give back
 
 // figure out the nickels to give back
 int changeNickels = neededChangeWhole / 5;
neededChangeWhole = neededChangeWhole %5;
 // update the remaining change to give back


 // figure out the pennies to give back
int changePennies = neededChangeWhole;


 // give the change back
 // remove the dollars, quarters, dimes, nickels, pennies
 // from the register
 // Hint code:
 // numberOfOneDollarBills -= changeDollars;
 numberOfOneDollarBills -= changeDollars;
 numberOfQuarters -= changeQuarters;
 numberOfDimes -= changeDimes;
 numberOfNickels -= changeNickels;
 numberOfPennies -= changePennies;
 // output to the console the change:
 // dollars, quarters, dimes, nickels, pennies
 // Hint code:
  System.out.printf("Dollars:\t\t %-15d\n", changeDollars);
  System.out.printf("Quaters:\t\t %-15d\n", changeQuarters);
  System.out.printf("Dimes: \t\t\t %-15d\n", changeDimes);
  System.out.printf("Nickels: \t\t %-15d\n", changeNickels);
  System.out.printf("Pennies: \t\t %-15d\n", changePennies);

 }

}//end class
 






